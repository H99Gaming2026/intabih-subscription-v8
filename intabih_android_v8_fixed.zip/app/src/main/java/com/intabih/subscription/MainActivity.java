package com.intabih.subscription;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.*;
import org.json.JSONObject;
import java.util.Calendar;

public class MainActivity extends Activity {
    private WebView web;
    private static final String CHANNEL_ID = "subscription_reminders";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        createNotificationChannel();
        requestNotificationPermission();
        requestExactAlarmAccess();
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        web.setWebChromeClient(new WebChromeClient());
        web.setBackgroundColor(0xFF0B1220);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 44);
    }

    private void requestExactAlarmAccess() {
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = getSystemService(AlarmManager.class);
            if (am != null && !am.canScheduleExactAlarms()) {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()))); }
                catch (Exception ignored) { }
            }
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "تذكيرات الاشتراكات", NotificationManager.IMPORTANCE_HIGH));
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    public static class AndroidBridge {
        private final Context context;
        AndroidBridge(Context c) { context = c.getApplicationContext(); }

        @JavascriptInterface public void scheduleSubscription(String json) {
            try {
                JSONObject s = new JSONObject(json);
                String id = s.getString("id");
                String name = s.getString("name");
                String date = s.getString("date");
                // Persist subscription data so alarms can be restored after a device reboot.
                context.getSharedPreferences("subscription_alarms", Context.MODE_PRIVATE)
                    .edit().putString(id, new JSONObject().put("name", name).put("date", date).toString()).apply();
                scheduleAlarms(context, id, name, date);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface public void cancelSubscription(String id) {
            cancelAlarms(context, id);
            context.getSharedPreferences("subscription_alarms", Context.MODE_PRIVATE).edit().remove(id).apply();
        }
    }

    static void restoreAllAlarms(Context context) {
        android.content.SharedPreferences prefs = context.getSharedPreferences("subscription_alarms", Context.MODE_PRIVATE);
        for (String id : prefs.getAll().keySet()) {
            try {
                JSONObject item = new JSONObject(prefs.getString(id, "{}"));
                scheduleAlarms(context, id, item.getString("name"), item.getString("date"));
            } catch (Exception ignored) { }
        }
    }

    private static final int[] MINUTES_BEFORE = {1440, 600, 10};

    private static void scheduleAlarms(Context context, String id, String name, String date) {
        try {
            String[] p = date.split("-");
            Calendar target = Calendar.getInstance();
            target.set(Calendar.YEAR, Integer.parseInt(p[0]));
            target.set(Calendar.MONTH, Integer.parseInt(p[1]) - 1);
            target.set(Calendar.DAY_OF_MONTH, Integer.parseInt(p[2]));
            target.set(Calendar.HOUR_OF_DAY, 23);
            target.set(Calendar.MINUTE, 59);
            target.set(Calendar.SECOND, 59);
            target.set(Calendar.MILLISECOND, 0);
            long expiry = target.getTimeInMillis();
            cancelAlarms(context, id);
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            for (int minutes : MINUTES_BEFORE) {
                long when = expiry - minutes * 60L * 1000L;
                if (when <= System.currentTimeMillis()) continue;
                Intent intent = new Intent(context, ReminderReceiver.class);
                intent.putExtra("name", name);
                intent.putExtra("minutes", minutes);
                intent.putExtra("id", id);
                int request = (id + "_" + minutes).hashCode() & 0x7fffffff;
                PendingIntent pi = PendingIntent.getBroadcast(context, request, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
                else if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
                else am.set(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (Exception ignored) { }
    }

    private static void cancelAlarms(Context context, String id) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        for (int minutes : MINUTES_BEFORE) {
            Intent intent = new Intent(context, ReminderReceiver.class);
            int request = (id + "_" + minutes).hashCode() & 0x7fffffff;
            PendingIntent pi = PendingIntent.getBroadcast(context, request, intent, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) { if (am != null) am.cancel(pi); pi.cancel(); }
        }
    }
}
