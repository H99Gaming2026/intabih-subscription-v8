package com.intabih.subscription;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;

        String name = intent.getStringExtra("name");
        int minutes = intent.getIntExtra("minutes", 0);
        String msg;
        if (minutes == 1440) msg = "باقي يوم واحد على انتهاء الاشتراك.";
        else if (minutes == 600) msg = "باقي 10 ساعات على انتهاء الاشتراك.";
        else msg = "باقي 10 دقائق فقط على انتهاء الاشتراك!";

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(context, "subscription_reminders")
            : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("تذكير باشتراكك: " + (name == null ? "" : name))
            .setContentText(msg)
            .setStyle(new Notification.BigTextStyle().bigText(msg))
            .setAutoCancel(true);
        String id = intent.getStringExtra("id");
        nm.notify(((id == null ? 1 : id.hashCode()) * 31) + minutes, b.build());
    }
}
